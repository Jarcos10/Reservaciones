package org.example.reservaciones.core.config;

import io.swagger.v3.oas.models.ExternalDocumentation;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI reservacionesOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("API de Reservaciones")
                        .description("Documentación de los servicios REST del sistema de reservaciones")
                        .version("1.0.0")
                        .contact(new Contact()
                                .name("Julio Cesar Arcos Salazar")
                                .email("julio.arcos.salazar@gmail.com"))
                        .license(new License()
                                .name("Uso académico")
                                .url("https://example.com")))
                .externalDocs(new ExternalDocumentation()
                        .description("Documentación general del proyecto")
                        .url("https://example.com/docs"));
    }
}
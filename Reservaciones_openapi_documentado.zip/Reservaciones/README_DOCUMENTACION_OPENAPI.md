# Documentación OpenAPI / Swagger agregada

Esta versión del proyecto incluye documentación descriptiva para cumplir la rúbrica de controladores, parámetros, respuestas, entidades principales y seguridad.

## Módulos documentados

### Habitaciones / Cuartos
Archivo principal:

```text
src/main/java/org/example/reservaciones/features/cuarto/controller/CuartoController.java
```

Incluye documentación para:

- Registrar habitación.
- Consultar todas las habitaciones.
- Consultar habitaciones disponibles por rango de fechas.
- Consultar una habitación por id.
- Actualizar habitación.
- Cambiar disponibilidad.
- Eliminar habitación.

También se documentaron sus DTOs:

```text
CreateCuartoDTO.java
UpdateCuartoDTO.java
UpdateDisponibilidadDTO.java
CuartoDTO.java
```

### Reservaciones
Archivo principal:

```text
src/main/java/org/example/reservaciones/features/reservacion/controller/ReservacionController.java
```

Incluye documentación para:

- Crear reservación.
- Crear reservación con identificación en multipart/form-data.
- Consultar reservaciones.
- Consultar reservación por id.
- Consultar reservaciones por cuarto.
- Confirmar reservación.
- Cancelar reservación.
- Finalizar reservación.
- Eliminar reservación.

También se documentaron sus DTOs:

```text
CreateReservacionDTO.java
ReservacionDTO.java
```

### Autenticación y seguridad
Archivo principal:

```text
src/main/java/org/example/reservaciones/core/security/controller/AuthController.java
```

Incluye documentación para:

- Validar credenciales mediante HTTP Basic.
- Registrar usuario.
- Consultar usuario autenticado.

También se documentaron:

```text
RegisterRequestDTO.java
UsuarioDTO.java
RolUsuario.java
Usuario.java
SecurityConfig.java
OpenApiConfig.java
```

## Seguridad documentada

El proyecto usa Spring Security con HTTP Basic, no JWT.

En Swagger aparece el esquema:

```text
basicAuth
```

Para probar endpoints protegidos se debe presionar el botón **Authorize** e ingresar correo y contraseña.

Roles definidos:

```text
ADMIN   -> administración del sistema, habitaciones, reservaciones y archivos.
USUARIO -> creación y gestión básica del flujo de reservación.
```

## Códigos de respuesta documentados

Se agregaron descripciones para respuestas comunes:

- `200 OK`: consulta o actualización correcta.
- `201 Created`: recurso creado correctamente.
- `204 No Content`: eliminación correcta sin cuerpo de respuesta.
- `400 Bad Request`: errores de validación o reglas de negocio.
- `401 Unauthorized`: credenciales faltantes o inválidas.
- `403 Forbidden`: usuario autenticado sin rol suficiente.
- `404 Not Found`: recurso no encontrado.
- `409 Conflict`: conflicto de datos, como correo ya registrado.

## Entidades principales documentadas

Se agregaron anotaciones `@Schema` a las entidades principales y enums del dominio:

```text
Cuarto.java
Reservacion.java
Archivo.java
Usuario.java
EstadoReservacion.java
RolUsuario.java
TipoDocumento.java
```

El objetivo es que Swagger muestre descripciones claras de qué representa cada entidad, sus campos y su uso dentro del sistema.

## Ruta de Swagger

Según la configuración actual del proyecto:

```text
http://localhost:8090/documentacion/swagger-ui.html
```

